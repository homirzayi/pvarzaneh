import Slider from "../components/ControlledCarousel";

function Home() {
  return (
    <>
      <Slider />
    </>
  );
}

export default Home;
